import UIKit
import React

public protocol ReactNativeDelegateInternal: AnyObject {
    func onAppClosed()
}

open class ReactNative: NSObject, RCTReloadListener {
    // MARK: - Properties
    private var mendixApp: MendixApp?
    private var bundleUrl: URL?
    private var launchOptions: [AnyHashable: Any]?

    public weak var delegate: ReactNativeDelegateInternal?
    
    // MARK: - Singleton
    public static let shared = ReactNative()
    
    private override init() {
        super.init()
    }
    
    // MARK: - Setup Methods
    public func setup(_ mendixApp: MendixApp, launchOptions: [AnyHashable: Any]? = nil) {
        self.mendixApp = mendixApp
        self.bundleUrl = mendixApp.bundleUrl
        self.launchOptions = launchOptions

        if let host = bundleUrl?.host, let port = bundleUrl?.port {
            let jsLocation = "\(host):\(port)"
            RCTBundleURLProvider.sharedSettings().jsLocation = jsLocation
        }
    }
    
    // MARK: - Lifecycle Methods
    @MainActor
    public func start() {
        guard let mendixApp = self.mendixApp else {
            fatalError("MendixApp not passed before starting the app")
        }
        
        MxConfiguration.update(from: mendixApp)
        
        if mendixApp.clearDataAtLaunch {
            StorageHelper.clearAll()
        }
        
        if let reactAppProvider = ReactAppProvider.shared() {
            reactAppProvider.setReactViewController(
                mendixApp.reactLoading?.instantiateInitialViewController() ?? UIViewController(),
                launchOptions: launchOptions
            )
            launchOptions = nil
        }
        
        DevHelper.setShakeToShowDevMenuEnabled(enabled: AppPreferences.devModeEnabled)
        DevHelper.setDebugMode(enabled: AppPreferences.devModeEnabled && AppPreferences.remoteDebuggingEnabled)
        
        showSplashScreen()
        
        if mendixApp.isDeveloperApp || mendixApp.enableThreeFingerGestures {
            DispatchQueue.main.async {
                RCTRegisterReloadCommandListener(self)
            }
        }
    }
    
    @MainActor
    public func stop() {
        hideSplashScreen()
        delegate?.onAppClosed()
        delegate = nil
    }
    
    // MARK: - Splash Screen Methods
    @MainActor
    public func showSplashScreen() {
        mendixApp?.splashScreenPresenter?.show(ReactAppProvider.shared()?.rootView)
    }
    
    @MainActor
    public func hideSplashScreen() {
        mendixApp?.splashScreenPresenter?.hide()
        DevHelper.hideDevLoadingView()
    }
    
    // MARK: - Reload Methods
    public func reload() {
        guard mendixApp != nil else { return }

        // Note: under the New Architecture the bundle URL is resolved fresh in bundleURL(),
        // which RCTHost re-invokes on reload. RCTReloadCommandSetBundleURL is a legacy-bridge
        // mechanism that the bridgeless host ignores, so it is intentionally not used here.

        RCTTriggerReloadCommandListeners("Reload command from app")
    }
    
    // MARK: - RCTReloadListener
    @objc public func didReceiveReloadCommand() {
        // Reload listeners run on the thread that triggered the reload (e.g. RCTExceptionsManager
        // off the main thread), so hop to main.
        DispatchQueue.main.async { self.showSplashScreen() }
    }
    
    // MARK: - Debugging Methods
    @MainActor
    public func remoteDebugging(_ enable: Bool) {
        showSplashScreen()
        bundleUrl = AppUrl.forBundle(
            AppPreferences.safeAppUrl,
            port: AppPreferences.remoteDebuggingPackagerPort,
            isDebuggingRemotely: enable,
            isDevModeEnabled: true
        )
        DevHelper.setDebugMode(enabled: enable)
    }
    
    @MainActor
    public func setRemoteDebuggingPackagerPort(_ port: Int) {
        AppPreferences.remoteDebuggingPackagerPort = port
        remoteDebugging(true)
    }
    
    public func bundleURL() -> URL? {
        // New Architecture (Bridgeless): RCTHost re-invokes this provider block on every
        // reload (via RCTRootViewFactory's bundleURLBlock) instead of consulting the URL set
        // by RCTReloadCommandSetBundleURL. Resolve the OTA bundle fresh here so a freshly
        // deployed OTA bundle is picked up after reload. Without this, every reload re-loads
        // the bundle captured at host-creation time and the app loops:
        // download -> deploy -> reload -> same bundle.
        //
        // For the developer app (and remote debugging) the cached packager URL must be used,
        // so only the production path re-resolves through BundleHelper.
        if mendixApp?.isDeveloperApp == true {
            return bundleUrl
        }
        return BundleHelper.getJSBundleFile()
    }
}

