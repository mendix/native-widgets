export declare const MxConfiguration: import("./NativeMxConfig").Configuration;
//# sourceMappingURL=index.d.ts.map