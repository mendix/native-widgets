export declare const MxEncryption: {
    setItem(key: string, value: string): Promise<void>;
    getItem(key: string): Promise<string | null>;
    removeItem(key: string): Promise<void>;
    clear(): Promise<void>;
    isEncrypted(): boolean;
};
//# sourceMappingURL=index.d.ts.map