import { type OnReloadWithState } from './reload-handler/NativeMxReload';
import { type OnDownloadProgress } from './ota/NativeMxOta';
export declare const onReloadWithStateEvent: OnReloadWithState;
export declare const onDownloadProgressEvent: OnDownloadProgress;
//# sourceMappingURL=events.d.ts.map