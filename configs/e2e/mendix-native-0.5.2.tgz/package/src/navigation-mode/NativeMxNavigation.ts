import type { TurboModule, CodegenTypes } from 'react-native';

const TurboModuleRegistry = require('react-native/Libraries/TurboModule/TurboModuleRegistry') as {
  getEnforcing: <T extends object>(name: string) => T;
};

export interface Spec extends TurboModule {
  isNavigationBarActive(): boolean;
  getNavigationBarHeight(): CodegenTypes.Double;
}

export default TurboModuleRegistry.getEnforcing<Spec>('MxNavigation');
