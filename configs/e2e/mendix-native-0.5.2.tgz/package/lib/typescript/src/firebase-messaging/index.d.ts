export declare const RNFBMessagingModule: {
    readonly isAvailable: boolean;
    hasPermission(): Promise<number>;
};
//# sourceMappingURL=index.d.ts.map