export declare const MxConfiguration: import("./NativeMxConfiguration").Configuration;
//# sourceMappingURL=index.d.ts.map