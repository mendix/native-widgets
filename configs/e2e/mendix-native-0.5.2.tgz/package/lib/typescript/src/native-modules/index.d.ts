export declare const getNativeModule: <T extends object = Record<string, unknown>>(name: string) => T | null;
//# sourceMappingURL=index.d.ts.map