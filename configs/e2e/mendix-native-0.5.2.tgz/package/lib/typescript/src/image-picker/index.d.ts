export declare const ImagePickerManager: {
    /**
     * `react-native-image-picker` v3 dropped the legacy action-sheet API. Its native module is
     * only present pre-v3; use that as a version marker instead of duplicating this check at
     * every call site.
     */
    readonly version: 2 | 4;
};
//# sourceMappingURL=index.d.ts.map