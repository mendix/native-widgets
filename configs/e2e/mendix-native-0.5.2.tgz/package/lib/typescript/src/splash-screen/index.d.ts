export declare const MendixSplashScreen: {
    show(): void;
    hide(): void;
};
//# sourceMappingURL=index.d.ts.map