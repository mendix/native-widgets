export declare const ScheduleEA: {
    readonly isAvailable: boolean;
    checkPermission(callback: (isEnabled: boolean) => void): void;
};
//# sourceMappingURL=index.d.ts.map