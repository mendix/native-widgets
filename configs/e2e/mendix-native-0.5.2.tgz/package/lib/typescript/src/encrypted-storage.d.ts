export declare const RNMendixEncryptedStorage: {
    getItem: (key: string) => Promise<string | null>;
    setItem: (key: string, value: string) => Promise<void>;
    removeItem: (key: string) => Promise<void>;
    clear: () => Promise<void>;
    IS_ENCRYPTED: boolean;
};
//# sourceMappingURL=encrypted-storage.d.ts.map