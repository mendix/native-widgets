import { type TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    clearAll(): Promise<void>;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeMxCookie.d.ts.map