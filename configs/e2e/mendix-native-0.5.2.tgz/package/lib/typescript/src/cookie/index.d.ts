export declare const NativeCookie: {
    clearAll: () => Promise<void>;
};
//# sourceMappingURL=index.d.ts.map