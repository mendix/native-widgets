import { type BlobData } from './NativeMxFileSystem';
export declare const NativeFileSystem: {
    DocumentDirectoryPath: string;
    SUPPORTS_DIRECTORY_MOVE: boolean | undefined;
    SUPPORTS_ENCRYPTION: boolean | undefined;
    read: (filePath: string) => Promise<BlobData>;
    list: (dirPath: string) => Promise<string[]>;
    readAsDataURL: (filePath: string) => Promise<string>;
    readAsText: (filePath: string) => Promise<string>;
    fileExists: (filePath: string) => Promise<boolean>;
    move: (filePath: string, newPath: string) => Promise<void>;
    remove: (filePath: string) => Promise<void>;
    setEncryptionEnabled: (enabled: boolean) => void;
    save: (blob: BlobData, filePath: string) => Promise<void>;
    writeJson: (data: Record<string, any>, filepath: string) => Promise<void>;
    readJson: <T>(filepath: string) => Promise<T>;
    relativeToDocumentsAbsolutePath: (path: string) => string;
};
//# sourceMappingURL=index.d.ts.map