export declare const NotifeeApiModule: {
    readonly isAvailable: boolean;
};
//# sourceMappingURL=index.d.ts.map