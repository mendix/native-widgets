import type { TurboModule, CodegenTypes } from 'react-native';
export interface Spec extends TurboModule {
    isNavigationBarActive(): boolean;
    getNavigationBarHeight(): CodegenTypes.Double;
}
declare const NativeMxNavigation: Spec;
export default NativeMxNavigation;
//# sourceMappingURL=NativeMxNavigation.d.ts.map