export declare const AndroidNavigationBar: {
    readonly height: number;
    readonly isActive: boolean;
};
//# sourceMappingURL=index.d.ts.map