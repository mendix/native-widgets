export declare const NativeErrorHandler: {
    handle: (message: string, stackTrace: import("stacktrace-parser").StackFrame[]) => void;
};
//# sourceMappingURL=index.d.ts.map