import { type TurboModule } from 'react-native';
import type { StackFrame } from 'stacktrace-parser';
export interface Spec extends TurboModule {
    handle(message: string, stackTrace: StackFrame[]): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeMxError.d.ts.map