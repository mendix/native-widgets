import { type TurboModule } from 'react-native';
import type { CodegenTypes } from 'react-native';
type DownloadConfig = {
    connectionTimeout?: CodegenTypes.Int32;
    mimeType?: string;
};
type DownloadProgress = {
    receivedBytes: CodegenTypes.Double;
    totalBytes: CodegenTypes.Double;
};
export interface Spec extends TurboModule {
    download(url: string, downloadPath: string, config: DownloadConfig): Promise<void>;
    readonly onDownloadProgress: CodegenTypes.EventEmitter<DownloadProgress>;
}
declare const _default: Spec;
export default _default;
export type { DownloadConfig, DownloadProgress };
//# sourceMappingURL=NativeMxDownload.d.ts.map