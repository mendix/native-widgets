package com.mendix.mendixnative.fragment

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import com.facebook.react.devsupport.interfaces.DevSupportManager
import com.mendix.mendixnative.DevAppMenuHandler
import com.mendix.mendixnative.MendixInitializer
import com.mendix.mendixnative.activity.LaunchScreenHandler
import com.mendix.mendixnative.react.MendixApp
import com.mendix.mendixnative.util.MendixDoubleTapRecognizer
import java.io.Serializable

/**
 * Class used for Sample apps
 */
open class MendixReactFragment : ReactFragment(), MendixReactFragmentView {

  protected var mendixApp: MendixApp? = null
  private lateinit var mendixInitializer: MendixInitializer
  private var doubleTapReloadRecognizer = MendixDoubleTapRecognizer()

  val currentDevSupportManager: DevSupportManager?
    get() = reactHost?.devSupportManager

  companion object {
    const val ARG_MENDIX_APP = "arg_mendix_app"
    const val ARG_CLEAR_DATA = "arg_clear_data"
    const val ARG_USE_DEVELOPER_SUPPORT = "arg_use_developer_support"
    const val ARG_COMPONENT_NAME = "arg_component_name"
    const val ARG_LAUNCH_OPTIONS = "arg_launch_options"

    fun newInstance(
      componentName: String,
      launchOptions: Bundle?,
      mendixApp: MendixApp,
      clearData: Boolean,
      useDeveloperSupport: Boolean
    ): MendixReactFragment {
      val mendixReactFragment = MendixReactFragment()
      val args = Bundle()
      args.putString(ARG_COMPONENT_NAME, componentName)
      args.putBundle(ARG_LAUNCH_OPTIONS, launchOptions)
      args.putBoolean(ARG_CLEAR_DATA, clearData)
      args.putBoolean(ARG_USE_DEVELOPER_SUPPORT, useDeveloperSupport)
      args.putSerializable(ARG_MENDIX_APP, mendixApp)
      mendixReactFragment.arguments = args
      return mendixReactFragment
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    (activity !is LaunchScreenHandler).let {
      if (it) throw java.lang.IllegalArgumentException("The Activity needs to implement LaunchScreenHandler")
    }

    if (mendixApp == null) {
      mendixApp = getSerializableData(ARG_MENDIX_APP, MendixApp::class.java)
        ?: throw IllegalArgumentException("Mendix app is required")
    }

    if (reactHost == null) {
        throw IllegalStateException("ReactHost is not set. Make sure that the activity extends MendixReactActivity or that you set the reactHost manually")
    }

    val clearData = requireArguments().getBoolean(ARG_CLEAR_DATA, false)
    val hasRNDeveloperSupport = requireArguments().getBoolean(ARG_USE_DEVELOPER_SUPPORT, false)

    mendixInitializer =
      MendixInitializer(requireActivity(), reactHost!!, hasRNDeveloperSupport).also {
        it.onCreate(mendixApp!!, clearData)
      }

    super.onCreate(savedInstanceState)
  }

  inline fun <reified T : Serializable> getSerializableData(key: String?, clazz: Class<T>): T? {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      requireArguments().getSerializable<T?>(key, clazz)
    } else {
      @Suppress("DEPRECATION")
      val data = requireArguments().getSerializable(key)
      if (data is T) {
        return data
      }
      return null
    }
  }

  fun onNewIntent(intent: Intent) {
    reactHost?.currentReactContext?.let {
      it.onNewIntent(it.currentActivity, intent)
    }
  }

  override fun onDestroy() {
    mendixInitializer.onDestroy()
    super.onDestroy()
  }

  override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
    if (keyCode == KeyEvent.KEYCODE_MENU || doubleTapReloadRecognizer.didDoubleTapBacktick(
        keyCode,
        view
      )
    ) {
      if (mendixApp?.showExtendedDevMenu == true) {
        showDevAppMenu()
      }
      return true
    }
    return super.onKeyUp(keyCode, event)
  }

  override fun showDevAppMenu() {
    activity?.let {
      currentDevSupportManager?.showDevOptionsDialog()
    }
  }

  open fun onCloseProjectSelected() {
  }
}

interface MendixReactFragmentView : DevAppMenuHandler, BackButtonHandler {
  fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean
}

interface BackButtonHandler {
  fun onBackPressed(): Boolean
}
